function [support_mask] = Supp(original,p)
original_left = zeros(length(original),1);
original_right = zeros(length(original),1);
max_abs = find(abs(original) == max(abs(original)));
for ii = max_abs:length(original)
    if abs(original(ii)) > p*max(abs(original))
        original_right(ii) = 1;
    else
        break
    end
end
for ii = max_abs:-1:1
    if abs(original(ii)) > p*max(abs(original));
        original_left(ii) = 1;
    else
        break
    end
end
support_mask_b = original_left+original_right;
support_mask_b(find(support_mask_b~=0))= 1;
support_mask = support_mask_b;
        