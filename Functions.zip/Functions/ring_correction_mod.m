function k_traj_corr = ring_correction_mod(kSpace,indexes,N,temp_path)
% kSpace: input kSpace data with (nx,nray,ncoil), 
%         nray should be time-combined
% indexes: kSpace ray number that to use for gradient delay estimation,
%         better pick rays that are at steady state.
% N : tiny gold angle N (i.e.5).
addpath(strcat(getenv('TOOLBOX_PATH'), '/matlab/'));
kSpace = squeeze(kSpace);
[nx,np,nc] = size(kSpace);
%% convert to ring traj
traj = bart(strcat('traj -c -r -H -x',num2str(nx),' -y',num2str(np),' -s',num2str(N)));% put -H if [0-180), -G [0-360)
k1 = reshape(kSpace,[1 nx np nc]);
tR = traj(:,:,indexes);
k1R = k1(:,:,indexes,:);

% traj_compare = squeeze(traj(2,:,:)/nx) + 1i*squeeze(traj(1,:,:)/nx);
% traj_compare = 1i.*-real(traj_compare)-imag(traj_compare);
%% estimate gradient delay
dfile =  'ring_estdelay.txt';
if exist(dfile, 'file'); delete(dfile);end
diary(dfile)
bart('estdelay -R',tR,k1R);
diary off
fid = fopen(dfile);
traj_delay = fgetl(fid);
fclose(fid);

r_val = 2;
while(length(traj_delay) > 29)
if exist(dfile, 'file'); delete(dfile);end
diary(dfile)
if r_val > 4 
    traj_delay = '0.000000:0.000000:0.000000';
    break;
end
command = ['estdelay -R -r' num2str(r_val)];
bart(command,tR,k1R);
diary off
fid = fopen(dfile);
traj_delay = fgetl(fid);
fclose(fid);
disp(command)
r_val = r_val+0.5;
end
%% ring correction
traj_c = bart(strcat('traj -c -r -H -x',num2str(nx),' -y',num2str(np),' -s',num2str(N),' -q ',traj_delay));
k_traj_corr = squeeze(traj_c(2,:,:)/nx) + 1i*squeeze(traj_c(1,:,:)/nx);
% k_traj_corr = 1i.*-real(k_traj_corr)-imag(k_traj_corr);
end