function [reduced_non_k_space,reduced_k_space2,g_mask_k_space_sparse]=pre_interp_clean_mod(Coil1,slice_counter,N,timeframe)

[sr,sth,sz,nc]=size(Coil1);

reduced_non_k_space=zeros(sr,sr,sz,nc);

for coil_counter=1:nc
    [reduced_k_space,g_mask_k_space_sparse]=rad_to_cart_bilinear_sparse_gold_clean_mod(Coil1(:,:,:,coil_counter),1,slice_counter,coil_counter,N,timeframe);
%     [reduced_k_space,g_mask_k_space_sparse]=rad_to_cart_bilinear_sparse_gold_fibo(Coil1(:,:,:,coil_counter),1,MID,slice_counter,coil_counter,N);
%     keyboard
    for fr_counter=1:sz
        reduced_non_k_space(:,:,fr_counter,coil_counter)=fftshift(ifft2(fftshift(reduced_k_space(:,:,fr_counter))));
    end
%     keyboard
% g_mask_k_space_sparse2(:,:,:,coil_counter) = g_mask_k_space_sparse;  
reduced_k_space2(:,:,:,coil_counter) = reduced_k_space; 
end
% keyboard
return;
