
function [g_cart_k_space_sparse, g_mask_k_space_sparse]=rad_to_cart_bilinear_sparse_gold_clean_mod(sparse_radial_data,index_angle,slice_counter,coil_counter,N,timeframe)

[sx sy sz]=size(sparse_radial_data);

X=zeros(sx,sy);
Y=zeros(sx,sy);

g_X=zeros(sx,sy,sz);
g_Y=zeros(sx,sy,sz);

n_temp_X=zeros(sx,sy,sz);
n_temp_Y=zeros(sx,sy,sz);

g_cart_k_space_sparse=zeros(sx,sx,sz);
g_mask_k_space_sparse=zeros(sx,sx,sz);


% golden_angle=((sqrt(5)-1)/2)*pi;
tau = (1.0+sqrt(5.0))/2.0;
golden_angle = pi / (tau+N-1);

% counter_main=1;
counter_main=timeframe;
% if(sz==1)
%     counter_main=index_angle;
% end

for noi=1:sz
    
    clear X
    clear Y
    k=1;
    l=1;
    
    for ghty=1:sy
        
        %         theta_radian=(pha+ghty-1)*golden_angle;
        theta_radian=(counter_main-1)*golden_angle;
        theta_radian=mod(theta_radian,pi);
        
        k=1;
        for r=-(sx/2-1):sx/2
            [x y]=pol2cart(theta_radian,r);
            X(k,l)=x;
            Y(k,l)=y;
            k=k+1;
        end
        l=l+1;
        
        counter_main=counter_main+1;
        
    end
    
    g_X(:,:,noi)=X;
    g_Y(:,:,noi)=Y;
    
end

for noi=1:sz
    
    img=sparse_radial_data(:,:,noi);
    
    %     % density compensation
    %     len = size(img,1);
    %     H = designFilter('ram-lak', len, 1);
    %     H = H+10; % decrease the constant to weight more the high freq values
    %
    %     img = fftshift(img,1);
    %     img = (img.*repmat(H,1,size(img,2)));
    %     img = fftshift(img,1);
    %     % done
    
    clear Z
    Z=(flipud(img));
    %     Z=img;
    
    clear X
    clear Y
    X=g_X(:,:,noi);
    Y=g_Y(:,:,noi);
    
    clear XI
    clear YI
    XI=round(X);
    YI=round(Y);
    warning off
    
    clear ZI
    
    ZI=griddata(X,Y,Z,XI,YI);
    
    KI=zeros(size(ZI));
    ii=find(ZI>0);
    jj=find(ZI<=0);
    
    KI(ii)=ZI(ii);
    KI(jj)=ZI(jj);
    
    clear cart_k_space
    cart_k_space=KI;
    
    cart_k_space_sparse=zeros(sx,sx);
    mask_k_space_sparse=zeros(sx,sx);
    
    clear temp_X
    clear temp_Y
    
    temp_X=XI+sx/2;
    temp_Y=YI+sx/2;
    
    n_temp_X(:,:,noi)=temp_X;
    n_temp_Y(:,:,noi)=temp_Y;
    
    for i=1:sx
        for j=1:sy
            try
                cart_k_space_sparse(temp_Y(i,j),temp_X(i,j))=cart_k_space(i,j);
                mask_k_space_sparse(temp_Y(i,j),temp_X(i,j))=1;
            catch
            end
        end
    end
    
    g_cart_k_space_sparse(:,:,noi)=cart_k_space_sparse;
    g_mask_k_space_sparse(:,:,noi)=mask_k_space_sparse;
    
end

% mask_fl_name=strcat('g_mask_k_space_sparse_',int2str(MID),'_',int2str(slice_counter),'_',int2str(coil_counter),'.mat');
% if(~exist(mask_fl_name))
%     save(mask_fl_name,'g_mask_k_space_sparse')
% end

return;
