function kSpace_comp = coil_compression(kSpace,N)
[nx,ny,nz,nc] = size(kSpace);
data = reshape(kSpace,[nx*ny*nz nc]);
[coeff,~,~] = pca(data);
compressed_data = data*coeff(:,1:N);
kSpace_comp = reshape(compressed_data,[nx,ny,nz,N]);